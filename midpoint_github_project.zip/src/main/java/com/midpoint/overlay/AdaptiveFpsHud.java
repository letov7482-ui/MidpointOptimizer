package com.midpoint.overlay;

import com.midpoint.config.MidpointConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class AdaptiveFpsHud {
    public static void render(DrawContext context) {
        if (!MidpointConfig.adaptiveFpsHud) return;

        MinecraftClient client = MinecraftClient.getInstance();
        int fps = client.getCurrentFps();
        String text = "FPS: " + fps + " (Midpoint Adaptive)";
        
        int color = 0xFFFFFF;
        if (fps < 30) color = 0xFF0000;
        else if (fps < 60) color = 0xFFFF00;
        else color = 0x00FF00;

        context.drawTextWithShadow(client.textRenderer, Text.literal(text), 5, 5, color);
    }
}
