package com.midpoint;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.midpoint.config.MidpointConfig;

public class MidpointMod implements ClientModInitializer {
    public static final String MOD_ID = "midpoint";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing Midpoint Mod for Fabric 1.21.11");
        MidpointConfig.load();
    }
}
